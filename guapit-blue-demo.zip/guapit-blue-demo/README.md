# Guapit-Blue Typora文档



<p align="center">
<a href="https://www.mql5.com"><img src="https://img.shields.io/badge/软件-Typora-critical.svg"/></a>
<a href="#"><img src="https://img.shields.io/badge/主题名-Guapit--Blue-blue"/></a>
<a href="#"><img src="https://img.shields.io/badge/版本-v1.1.0-f1c232"/></a>
<img src="https://img.shields.io/badge/作者-阿龙-d90429"/>
<a href="#"><img src="https://img.shields.io/badge/QQ-8199231-ff69b4"/></a>
<a href="#"><img src="https://img.shields.io/badge/微信-guapitcom-success"/></a>
<a href="https://www.guapit.com"><img src="https://img.shields.io/badge/学习资料-guapit.com-yellowgreen"/></a>
<a href="#"><img src="https://img.shields.io/badge/E--mail-guapit%40qq.com-yellowgreen"/></a>
<a href="https://space.bilibili.com/342693735"><img src="https://img.shields.io/badge/B站-点击进入B站 >> 免费零基础 快速入门编程-0096c7"/></a>
</p><br>



## 官方文档参考

> Github: https://github.com/guapit/guapit-blue-typora-theme
>
> Gitee: [https://gitee.com/guapit/guapit-blue-typora-theme](https://gitee.com/guapit/guapit-blue-typora-theme)

### 安装方法

1 克隆下载

```bash
# github
git clone https://github.com/guapit/guapit-typora-theme.git
# gitee
git clone https://gitee.com/guapit/guapit-typora-theme.git
```

2 打开Typora文档软件

`文件(F)` > `偏好设置` > 选择 `外观` > `打开主题文件夹`

将下载好的 `theme` 目录的所有文件复制到 `Typora\themes`即可

<img src="https://gitee.com/guapit_com/mt5-tutorial-pictures/raw/master/images/mt5/gp-20221117212323.png" alt="image-20221114210415816" style="zoom:50%;" />

## 主题展示

![](https://gitee.com/guapit_com/mt5-tutorial-pictures/raw/master/images/mt5/gp-20221117212552.png)

## 代码效果

### JavaScript

![image-20221117212645151](https://gitee.com/guapit_com/mt5-tutorial-pictures/raw/master/images/mt5/gp-20221117212646.png)

### 